import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Star } from "lucide-react";

interface Point {
  id: number;
  x: number;
  y: number;
}

// Heart shape constellation points (proper heart shape)
const CONSTELLATION_POINTS: Point[] = [
  { id: 1, x: 50, y: 20 },  // Top center
  { id: 2, x: 65, y: 15 },  // Right top
  { id: 3, x: 75, y: 25 },  // Right side
  { id: 4, x: 65, y: 50 },  // Right middle
  { id: 5, x: 50, y: 75 },  // Bottom point
  { id: 6, x: 35, y: 50 },  // Left middle
  { id: 7, x: 25, y: 25 },  // Left side
  { id: 8, x: 35, y: 15 },  // Left top
];

export function HeartConstellation({ onComplete, onFail }: { onComplete: () => void; onFail: () => void }) {
  const [attempts, setAttempts] = useState(0);
  const [visited, setVisited] = useState<number[]>([]);
  const [message, setMessage] = useState("Trace the heart in the stars...");

  const handlePointClick = (id: number) => {
    if (visited.includes(id)) return;

    const nextExpected = CONSTELLATION_POINTS[visited.length].id;
    
    if (id === nextExpected) {
      const newVisited = [...visited, id];
      setVisited(newVisited);
      if (newVisited.length === CONSTELLATION_POINTS.length) {
        setTimeout(() => onComplete(), 500);
      }
    } else {
      const newAttempts = attempts + 1;
      setAttempts(newAttempts);
      setVisited([]);
      if (newAttempts >= 5) {
        onFail();
      } else {
        setMessage(`The connection faded. ${5 - newAttempts} attempts remaining.`);
        setTimeout(() => setMessage("Trace the heart in the stars..."), 2000);
      }
    }
  };

  return (
    <div className="fixed inset-0 z-[100] bg-slate-950/98 flex flex-col items-center justify-center p-4">
      {/* Header */}
      <motion.div 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-8 md:mb-12 text-center"
      >
        <h2 className="text-3xl md:text-5xl font-display text-transparent bg-clip-text bg-gradient-to-br from-indigo-100 via-purple-100 to-pink-100 mb-4 drop-shadow-[0_0_20px_rgba(255,255,255,0.3)]">
          Heart of the Sky
        </h2>
        <p className="text-indigo-200 text-lg md:text-xl font-serif italic">{message}</p>
      </motion.div>

      {/* Constellation Game Area */}
      <motion.div 
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 0.2 }}
        className="relative w-full max-w-[min(600px,90vw)] aspect-square"
      >
        {/* Background circle */}
        <div className="absolute inset-0 bg-gradient-to-br from-slate-900/40 to-indigo-950/40 rounded-full border-2 border-indigo-500/20 backdrop-blur-sm shadow-[0_0_60px_rgba(99,102,241,0.2)]" />

        {/* Connection lines */}
        <svg className="w-full h-full pointer-events-none absolute inset-0">
          <defs>
            <filter id="glow">
              <feGaussianBlur stdDeviation="3" result="coloredBlur"/>
              <feMerge>
                <feMergeNode in="coloredBlur"/>
                <feMergeNode in="SourceGraphic"/>
              </feMerge>
            </filter>
          </defs>
          {visited.length > 1 && visited.map((id, index) => {
            if (index === 0) return null;
            const p1 = CONSTELLATION_POINTS.find(p => p.id === visited[index-1])!;
            const p2 = CONSTELLATION_POINTS.find(p => p.id === id)!;
            return (
              <motion.line
                key={`line-${index}`}
                initial={{ pathLength: 0, opacity: 0 }}
                animate={{ pathLength: 1, opacity: 1 }}
                transition={{ duration: 0.3 }}
                x1={`${p1.x}%`} y1={`${p1.y}%`}
                x2={`${p2.x}%`} y2={`${p2.y}%`}
                stroke="url(#lineGradient)"
                strokeWidth="3"
                filter="url(#glow)"
              />
            );
          })}
          <defs>
            <linearGradient id="lineGradient" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#818cf8" />
              <stop offset="100%" stopColor="#ec4899" />
            </linearGradient>
          </defs>
        </svg>

        {/* Star points */}
        {CONSTELLATION_POINTS.map((point) => {
          const isVisited = visited.includes(point.id);
          const isNext = point.id === CONSTELLATION_POINTS[visited.length]?.id;
          
          return (
            <motion.button
              key={point.id}
              initial={{ scale: 0, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ delay: point.id * 0.1 }}
              whileHover={{ scale: isVisited ? 1 : 1.3 }}
              whileTap={{ scale: 0.9 }}
              onClick={(e) => {
                e.stopPropagation();
                handlePointClick(point.id);
              }}
              className={`absolute w-12 h-12 md:w-16 md:h-16 -ml-6 -mt-6 md:-ml-8 md:-mt-8 rounded-full transition-all duration-300 z-10 flex items-center justify-center ${
                isVisited 
                  ? "bg-gradient-to-br from-white to-pink-200 shadow-[0_0_40px_white] scale-110" 
                  : isNext
                    ? "bg-indigo-400/60 shadow-[0_0_30px_rgba(129,140,248,0.8)] animate-pulse"
                    : "bg-indigo-600/40 hover:bg-indigo-400/60 hover:shadow-[0_0_25px_rgba(129,140,248,0.6)]"
              }`}
              style={{ left: `${point.x}%`, top: `${point.y}%` }}
            >
              <Star 
                className={`w-6 h-6 md:w-8 md:h-8 transition-all ${
                  isVisited 
                    ? "text-indigo-900 fill-indigo-900" 
                    : "text-white/80 fill-white/20"
                }`} 
              />
              {isNext && !isVisited && (
                <motion.div
                  className="absolute inset-0 border-2 border-white rounded-full"
                  animate={{ scale: [1, 1.4, 1], opacity: [0.8, 0, 0.8] }}
                  transition={{ duration: 2, repeat: Infinity }}
                />
              )}
            </motion.button>
          );
        })}
      </motion.div>

      {/* Progress indicator */}
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.5 }}
        className="mt-8 md:mt-12 text-center"
      >
        <p className="text-indigo-400/60 text-sm md:text-base mb-4">
          {visited.length} / {CONSTELLATION_POINTS.length} stars connected
        </p>
        <div className="flex gap-2 justify-center">
          {CONSTELLATION_POINTS.map((_, index) => (
            <div 
              key={index}
              className={`w-2 h-2 rounded-full transition-all duration-300 ${
                index < visited.length 
                  ? 'bg-pink-400 shadow-[0_0_8px_rgba(244,114,182,0.8)]' 
                  : 'bg-slate-700'
              }`}
            />
          ))}
        </div>
      </motion.div>
    </div>
  );
}
