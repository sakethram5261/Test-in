import { ReactNode } from "react";
import { motion } from "framer-motion";
import { Sparkles } from "lucide-react";

interface ClueTextProps {
  children: ReactNode;
  isDiscovered?: boolean;
  onClick?: () => void;
}

export function ClueText({ children, isDiscovered = false, onClick }: ClueTextProps) {
  return (
    <span className="relative inline-block group">
      <motion.span
        onClick={onClick}
        whileHover={{ scale: 1.05 }}
        className={`
          cursor-pointer transition-all duration-300 px-1 rounded
          ${isDiscovered 
            ? 'text-amber-500 font-bold' 
            : 'text-foreground underline decoration-dotted decoration-amber-500/50 hover:bg-amber-500/10 hover:text-amber-600'}
        `}
      >
        {children}
      </motion.span>
      {isDiscovered && (
        <motion.span
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="absolute -top-6 left-1/2 -translate-x-1/2 text-amber-500 pointer-events-none"
        >
          <Sparkles className="w-4 h-4 fill-amber-500" />
        </motion.span>
      )}
    </span>
  );
}
