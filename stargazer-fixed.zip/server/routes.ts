import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  // GET /api/story/:sessionId
  app.get(api.story.get.path, async (req, res) => {
    const { sessionId } = req.params;
    const progress = await storage.getProgress(sessionId);
    if (!progress) {
      return res.status(404).json({ message: "Session not found" });
    }
    res.json(progress);
  });

  // POST /api/story
  app.post(api.story.create.path, async (req, res) => {
    try {
      const input = api.story.create.input.parse(req.body);
      const progress = await storage.createProgress(input);
      res.status(201).json(progress);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      throw err;
    }
  });

  // PATCH /api/story/:sessionId
  app.patch(api.story.update.path, async (req, res) => {
    const { sessionId } = req.params;
    try {
      const input = api.story.update.input.parse(req.body);
      
      // Check if session exists first
      const existing = await storage.getProgress(sessionId);
      if (!existing) {
        return res.status(404).json({ message: "Session not found" });
      }

      const updated = await storage.updateProgress(sessionId, input);
      res.json(updated);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      throw err;
    }
  });

  return httpServer;
}
