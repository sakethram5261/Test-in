import { useStorySession, useUpdateStory } from "@/hooks/use-story";
import { BookLayout, PageContent } from "@/components/BookLayout";
import { StarField } from "@/components/StarField";
import { useLocation } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import { ArrowRight, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { HeartConstellation } from "@/components/HeartConstellation";
import { useState } from "react";

export default function Chapter1() {
  const { data: session, isLoading } = useStorySession();
  const updateStory = useUpdateStory();
  const [, setLocation] = useLocation();
  const [showMinigame, setShowMinigame] = useState(false);

  if (isLoading || !session) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center">
        <Loader2 className="animate-spin text-white w-8 h-8" />
      </div>
    );
  }

  const handleComplete = async () => {
    await updateStory.mutateAsync({ storyPath: "voice", currentChapter: 2 });
    setLocation("/chapter/2");
  };

  const handleFail = async () => {
    await updateStory.mutateAsync({ storyPath: "sadness", currentChapter: 2 });
    setLocation("/chapter/2");
  };

  return (
    <>
      <AnimatePresence>
        {showMinigame && (
          <HeartConstellation onComplete={handleComplete} onFail={handleFail} />
        )}
      </AnimatePresence>

      {!showMinigame && (
        <BookLayout isNight={true}>
          <StarField />
          
          <PageContent className="border-r border-slate-800 bg-slate-900/50 backdrop-blur-sm">
            <div className="h-full flex flex-col justify-center items-center text-center p-8">
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="w-48 h-48 rounded-full bg-gradient-to-tr from-indigo-500/20 to-purple-500/20 blur-xl absolute"
              />
              <h2 className="text-4xl font-display text-transparent bg-clip-text bg-gradient-to-br from-indigo-100 via-purple-100 to-pink-100 mb-6 relative z-10 drop-shadow-[0_0_15px_rgba(255,255,255,0.3)]">
                Kaguya's Tale
              </h2>
              <div className="w-full h-px bg-gradient-to-r from-transparent via-indigo-500/50 to-transparent mb-8"></div>
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.5 }}
                className="text-indigo-300/60 text-sm italic font-serif"
              >
                Chapter One
              </motion.div>
            </div>
          </PageContent>

          <PageContent>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.3 }}
              className="prose prose-invert prose-lg max-w-none font-serif leading-loose"
            >
              <p className="text-indigo-100">
                The night air was crisp and still. He sat alone on the grassy hill, staring into the endless void above, searching for meaning in the darkness.
              </p>
              <p className="text-indigo-100">
                For years, the stars had been nothing but distant, cold points of light—beautiful, yet unreachable. But tonight, something was different.
              </p>
              <p className="text-indigo-100">
                The stars began to shift and align in a way they never had before. A heart, pulsing with a gentle, ethereal light, appeared right before his eyes—as if the cosmos itself was reaching out to him.
              </p>
              <div className="mt-12 flex justify-end">
                <Button 
                  onClick={() => setShowMinigame(true)} 
                  className="bg-indigo-600 hover:bg-indigo-500 text-white px-8 py-4 rounded-full text-lg group"
                >
                  Trace the stars 
                  <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
                </Button>
              </div>
            </motion.div>
          </PageContent>
        </BookLayout>
      )}
    </>
  );
}
