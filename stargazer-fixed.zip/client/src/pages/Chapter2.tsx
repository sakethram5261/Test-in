import { useStorySession, useUpdateStory } from "@/hooks/use-story";
import { BookLayout, PageContent } from "@/components/BookLayout";
import { StarField } from "@/components/StarField";
import { useLocation } from "wouter";
import { motion } from "framer-motion";
import { ArrowRight, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function Chapter2() {
  const { data: session, isLoading } = useStorySession();
  const updateStory = useUpdateStory();
  const [, setLocation] = useLocation();

  if (isLoading || !session) return <div className="min-h-screen bg-slate-950 flex items-center justify-center"><Loader2 className="animate-spin text-white" /></div>;

  const isVoice = session.storyPath === "voice";

  const handleNext = async () => {
    await updateStory.mutateAsync({ currentChapter: 3 });
    setLocation("/chapter/3");
  };

  return (
    <BookLayout isNight={true}>
      <StarField />
      <PageContent className="border-r border-slate-800 bg-slate-900/50 backdrop-blur-sm">
        <div className="h-full flex flex-col justify-center items-center text-center p-8">
          <h2 className="text-3xl font-display text-indigo-200 mb-6">{isVoice ? "The Voice" : "Eternal Sadness"}</h2>
          <div className="w-full h-px bg-gradient-to-r from-transparent via-indigo-500/50 to-transparent mb-8"></div>
        </div>
      </PageContent>
      <PageContent>
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="prose prose-invert prose-lg font-serif leading-loose">
          {isVoice ? (
            <>
              <p>A soft voice echoed across the hill. "You found me," it whispered.</p>
              <p>He followed the sound and there she was—Kaguya, bathed in moonlight. Her presence was like a dream given form, yet her eyes held a weight that grounded him.</p>
            </>
          ) : (
            <>
              <p>The stars went dim. A crushing weight settled in his chest. "If even the heavens are unreachable," he thought, "what hope is there for me?"</p>
              <p>He stood at the edge of the hill, looking down into the abyss. But just as he was about to let go, a hand caught his. Kaguya. "Not like this," she said softly, her touch warmer than any star.</p>
            </>
          )}
          <div className="mt-12 flex justify-end">
            <Button onClick={handleNext} variant="ghost" className="text-indigo-300 hover:text-white group">
              Search for clues <ArrowRight className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </Button>
          </div>
        </motion.div>
      </PageContent>
    </BookLayout>
  );
}
