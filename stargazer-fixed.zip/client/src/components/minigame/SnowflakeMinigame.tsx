import { useState, useEffect, useCallback, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Heart, Snowflake } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useUpdateStory } from "@/hooks/use-story";
import { useLocation } from "wouter";

interface FallingObject {
  id: number;
  x: number;
  y: number;
  speed: number;
  type: "heart" | "snowflake";
}

export function SnowflakeMinigame() {
  const [score, setScore] = useState(0);
  const [objects, setObjects] = useState<FallingObject[]>([]);
  const [isGameOver, setIsGameOver] = useState(false);
  const updateStory = useUpdateStory();
  const [, setLocation] = useLocation();
  const animationFrameRef = useRef<number>();
  const lastSpawnRef = useRef<number>(Date.now());

  const spawnObject = useCallback(() => {
    const now = Date.now();
    // Throttle spawning to prevent too many objects
    if (now - lastSpawnRef.current < 700) return;
    
    lastSpawnRef.current = now;
    const id = Math.random();
    const x = Math.random() * 85 + 7.5; // Keep objects away from edges
    const type = Math.random() > 0.35 ? "heart" : "snowflake";
    const speed = Math.random() * 1.5 + 1.8;
    
    setObjects((prev) => {
      // Limit total objects to prevent lag
      if (prev.length > 8) {
        return [...prev.slice(1), { id, x, y: -10, speed, type }];
      }
      return [...prev, { id, x, y: -10, speed, type }];
    });
  }, []);

  // Game loop with requestAnimationFrame
  useEffect(() => {
    if (isGameOver) return;

    const gameLoop = () => {
      setObjects((prev) => 
        prev
          .map((obj) => ({ ...obj, y: obj.y + obj.speed }))
          .filter((obj) => obj.y < 105)
      );
      
      // Spawn new objects occasionally
      if (Math.random() < 0.15) {
        spawnObject();
      }
      
      animationFrameRef.current = requestAnimationFrame(gameLoop);
    };

    animationFrameRef.current = requestAnimationFrame(gameLoop);

    return () => {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, [isGameOver, spawnObject]);

  const handleCatch = useCallback((id: number, type: "heart" | "snowflake") => {
    if (type === "heart") {
      setScore((s) => s + 1);
    } else {
      setScore((s) => Math.max(0, s - 2));
    }
    setObjects((prev) => prev.filter((obj) => obj.id !== id));
  }, []);

  const finishGame = async () => {
    setIsGameOver(true);
    let path = "standard";

    if (score > 15) {
      path = "imprisoned";
    } else if (score >= 10) {
      path = "execution";
    } else {
      // Not enough hearts - reset and try again
      setIsGameOver(false);
      setScore(0);
      setObjects([]);
      return;
    }

    await updateStory.mutateAsync({ 
      storyPath: path,
      currentChapter: 5,
      loveMeter: score
    });
    
    setLocation(path === "imprisoned" ? "/story/imprisoned" : "/story/execution");
  };

  return (
    <div className="relative w-full h-[600px] bg-slate-950/60 rounded-2xl overflow-hidden border border-indigo-500/30 backdrop-blur-xl shadow-2xl">
      {/* Score Display */}
      <div className="absolute top-6 left-8 z-20">
        <div className="text-indigo-300/60 text-xs font-mono uppercase tracking-[0.2em] mb-2">
          Hearts Collected
        </div>
        <div className="text-6xl font-display text-white drop-shadow-[0_0_15px_rgba(255,255,255,0.3)]">
          {score}
        </div>
      </div>

      {/* Finish Button */}
      <div className="absolute top-6 right-8 z-20">
        {score >= 10 && !isGameOver && (
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
          >
            <Button 
              onClick={finishGame}
              className="bg-indigo-500/30 border border-indigo-500/50 text-indigo-100 hover:bg-indigo-500/50 px-8 py-6 text-lg h-auto rounded-full transition-all duration-300 shadow-lg"
            >
              Stop Now
            </Button>
          </motion.div>
        )}
      </div>

      {/* Falling Objects */}
      <AnimatePresence>
        {objects.map((obj) => (
          <motion.div
            key={obj.id}
            initial={{ opacity: 0, scale: 0 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.5 }}
            transition={{ duration: 0.2 }}
            className="absolute cursor-pointer touch-none"
            style={{ 
              left: `${obj.x}%`, 
              top: `${obj.y}%`,
              transform: 'translate(-50%, -50%)'
            }}
            onPointerDown={(e) => {
              e.preventDefault();
              handleCatch(obj.id, obj.type);
            }}
          >
            {obj.type === "heart" ? (
              <div className="relative group p-2">
                <div className="absolute inset-0 bg-pink-500/20 blur-xl rounded-full scale-150 group-hover:bg-pink-500/40 transition-colors" />
                <Heart className="text-pink-400 fill-pink-400/50 w-10 h-10 md:w-12 md:h-12 relative z-10 filter drop-shadow-[0_0_12px_rgba(244,114,182,0.8)]" />
                <Snowflake className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-white/40 w-6 h-6 animate-spin z-20" style={{ animationDuration: '3s' }} />
              </div>
            ) : (
              <div className="relative group p-2">
                <div className="absolute inset-0 bg-blue-500/10 blur-lg rounded-full scale-125" />
                <Snowflake className="text-blue-200 w-8 h-8 md:w-10 md:h-10 opacity-80 relative z-10 animate-spin" style={{ animationDuration: '4s' }} />
              </div>
            )}
          </motion.div>
        ))}
      </AnimatePresence>

      {/* Instructions */}
      <div className="absolute bottom-6 left-0 right-0 text-center pointer-events-none px-12">
        <AnimatePresence mode="wait">
          {score > 10 ? (
            <motion.p 
              key="greed-text"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-indigo-300/80 italic text-sm md:text-base tracking-wide font-serif"
            >
              "The warmth is intoxicating... but the King's eyes are always watching."
            </motion.p>
          ) : (
            <motion.p 
              key="instruct-text"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="text-indigo-400/60 text-xs md:text-sm uppercase tracking-widest"
            >
              Catch 10 hearts to survive the frost • Avoid the snowflakes
            </motion.p>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
