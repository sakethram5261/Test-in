import { BookLayout, PageContent } from "@/components/BookLayout";
import { StarField } from "@/components/StarField";
import { motion } from "framer-motion";
import { Skull, Lock, RotateCcw } from "lucide-react";
import { Button } from "@/components/ui/button";

export function Imprisoned() {
  const handleRestart = () => {
    localStorage.removeItem("stargazer_session_id");
    window.location.href = "/";
  };

  return (
    <BookLayout isNight={true}>
      <StarField />
      <PageContent className="border-r border-slate-800 bg-slate-900/50 backdrop-blur-sm">
        <div className="h-full flex flex-col justify-center items-center text-center p-8">
          <motion.div 
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="w-32 h-32 rounded-lg border-2 border-indigo-500/30 flex items-center justify-center mb-6"
          >
            <Lock className="w-16 h-16 text-indigo-400" />
          </motion.div>
          <h2 className="text-3xl font-display text-indigo-200 mb-4">The Gilded Cage</h2>
          <div className="w-full h-px bg-gradient-to-r from-transparent via-indigo-500/50 to-transparent"></div>
        </div>
      </PageContent>
      <PageContent>
        <motion.div 
          initial={{ opacity: 0 }} 
          animate={{ opacity: 1 }} 
          className="prose prose-invert prose-lg font-serif leading-loose h-full flex flex-col justify-between"
        >
          <div>
            <p>The King did not come with fire, but with silence.</p>
            <p>Because you sought too much warmth from the frozen hearts, he deemed you a thief of the stars. "If you love the cold so much," he whispered, "you shall live within it forever."</p>
            <p>The iron doors groaned shut. The Princess is gone, and you are but a shadow in the tower.</p>
            <p className="text-indigo-300/60 italic mt-8">Your greed for warmth has sealed your fate in eternal frost.</p>
          </div>
          
          <div className="flex justify-center mt-12">
            <Button 
              onClick={handleRestart}
              className="bg-indigo-600 hover:bg-indigo-500 text-white px-8 py-6 text-lg rounded-full"
            >
              <RotateCcw className="mr-2 w-5 h-5" />
              Begin a New Journey
            </Button>
          </div>
        </motion.div>
      </PageContent>
    </BookLayout>
  );
}

export function Execution() {
  const handleRestart = () => {
    localStorage.removeItem("stargazer_session_id");
    window.location.href = "/";
  };

  return (
    <BookLayout isNight={true}>
      <StarField />
      <PageContent className="border-r border-red-900/30 bg-red-950/20 backdrop-blur-sm">
        <div className="h-full flex flex-col justify-center items-center text-center p-8">
          <motion.div 
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            className="w-32 h-32 rounded-full border-2 border-red-500/30 flex items-center justify-center mb-6"
          >
            <Skull className="w-16 h-16 text-red-400" />
          </motion.div>
          <h2 className="text-3xl font-display text-red-200 mb-4">The Final Breath</h2>
          <div className="w-full h-px bg-gradient-to-r from-transparent via-red-500/50 to-transparent"></div>
        </div>
      </PageContent>
      <PageContent>
        <motion.div 
          initial={{ opacity: 0 }} 
          animate={{ opacity: 1 }} 
          className="prose prose-invert prose-lg font-serif leading-loose h-full flex flex-col justify-between"
        >
          <div>
            <p>You stopped when the cold began to bite, but it was not enough.</p>
            <p>The King saw your hesitation as weakness. "A heart that fears the frost cannot serve the crown," he declared. The Princess wept as the guards took you toward the chopping block.</p>
            <p>The stars look down, indifferent to the blood that will soon stain the snow.</p>
            <p className="text-red-300/60 italic mt-8">You lacked the courage to claim enough warmth for yourself.</p>
          </div>
          
          <div className="flex justify-center mt-12">
            <Button 
              onClick={handleRestart}
              className="bg-red-600 hover:bg-red-500 text-white px-8 py-6 text-lg rounded-full"
            >
              <RotateCcw className="mr-2 w-5 h-5" />
              Begin a New Journey
            </Button>
          </div>
        </motion.div>
      </PageContent>
    </BookLayout>
  );
}
