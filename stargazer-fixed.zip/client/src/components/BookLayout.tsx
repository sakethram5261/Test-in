import { ReactNode } from "react";
import { motion } from "framer-motion";

interface BookLayoutProps {
  children: ReactNode;
  className?: string;
  isNight?: boolean;
}

export function BookLayout({ children, className = "", isNight = false }: BookLayoutProps) {
  return (
    <div className={`min-h-screen w-full flex items-center justify-center p-4 md:p-8 transition-colors duration-1000 ${isNight ? 'bg-slate-950' : 'bg-[#e8dfce]'}`}>
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.8, ease: "easeOut" }}
        className={`
          relative w-full max-w-5xl min-h-[85vh] 
          ${isNight ? 'bg-slate-900 text-slate-100 border-slate-800' : 'bg-[#fdfbf7] text-slate-800 border-[#e6dcc6]'}
          rounded-xl shadow-2xl overflow-hidden book-page border
          flex flex-col md:flex-row
          ${className}
        `}
      >
        {/* Decorative Spine/Gutter for book effect */}
        <div className={`
          hidden md:block absolute left-1/2 top-0 bottom-0 w-12 -ml-6 z-20
          bg-gradient-to-r 
          ${isNight 
            ? 'from-transparent via-slate-950/40 to-transparent' 
            : 'from-transparent via-[#e0d5be]/50 to-transparent'}
          pointer-events-none
        `}></div>
        
        {/* Texture overlay */}
        <div className="absolute inset-0 opacity-[0.03] pointer-events-none z-10 bg-[url('https://www.transparenttextures.com/patterns/paper.png')] mix-blend-multiply"></div>

        {children}
      </motion.div>
    </div>
  );
}

export function PageContent({ children, className = "" }: { children: ReactNode, className?: string }) {
  return (
    <div className={`flex-1 p-8 md:p-12 lg:p-16 flex flex-col justify-center relative z-0 ${className}`}>
      {children}
    </div>
  );
}
