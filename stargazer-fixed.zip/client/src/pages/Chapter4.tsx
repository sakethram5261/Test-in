import { useStorySession, useUpdateStory } from "@/hooks/use-story";
import { BookLayout, PageContent } from "@/components/BookLayout";
import { StarField } from "@/components/StarField";
import { useLocation } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import { Loader2, Lock, Heart, Snowflake } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { SnowflakeMinigame } from "@/components/minigame/SnowflakeMinigame";

export default function Chapter4() {
  const { data: session, isLoading } = useStorySession();
  const updateStory = useUpdateStory();
  const [, setLocation] = useLocation();
  const [password, setPassword] = useState("");
  const [showMinigame, setShowMinigame] = useState(false);
  const { toast } = useToast();

  if (isLoading || !session) return <div className="min-h-screen bg-slate-950 flex items-center justify-center"><Loader2 className="animate-spin text-white" /></div>;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (password.toLowerCase().trim() === "i love you") {
      setShowMinigame(true);
    } else {
      toast({
        title: "The stars remain silent",
        description: "That is not the truth they are waiting for.",
        variant: "destructive"
      });
    }
  };

  return (
    <BookLayout isNight={true}>
      <StarField />
      
      <AnimatePresence mode="wait">
        {showMinigame ? (
          <motion.div
            key="minigame"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-slate-950/90 flex items-center justify-center p-4"
          >
            <div className="w-full max-w-4xl bg-slate-900/50 rounded-2xl border border-indigo-500/20 p-8 backdrop-blur-xl">
              <div className="text-center mb-8">
                <h2 className="text-3xl font-display text-white mb-2">The Frozen Hearts</h2>
                <p className="text-indigo-200 font-serif italic">Catch the warmth before it fades...</p>
              </div>
              <SnowflakeMinigame />
              <div className="mt-8 text-center">
                <Button 
                  onClick={() => setShowMinigame(false)} 
                  variant="ghost" 
                  className="text-indigo-400 hover:text-indigo-300"
                >
                  Return to the seal
                </Button>
              </div>
            </div>
          </motion.div>
        ) : (
          <>
            <PageContent className="border-r border-slate-800 bg-slate-900/50 backdrop-blur-sm">
              <div className="h-full flex flex-col justify-center items-center text-center p-8">
                <Lock className="w-16 h-16 text-indigo-400 mb-6" />
                <h2 className="text-3xl font-display text-indigo-200">The Final Seal</h2>
                <div className="w-full h-px bg-gradient-to-r from-transparent via-indigo-500/50 to-transparent mb-8"></div>
              </div>
            </PageContent>
            <PageContent>
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-center space-y-8">
                <p className="prose prose-invert prose-lg font-serif italic mx-auto">
                  "The clues lead to this one moment. The truth is not in the stars, but in what you've felt since the first heartbeat."
                </p>
                
                <form onSubmit={handleSubmit} className="max-w-xs mx-auto space-y-4">
                  <Input
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="The truth..."
                    className="bg-slate-900/50 border-indigo-500/50 text-indigo-100 placeholder:text-indigo-300/30 text-center"
                  />
                  <Button type="submit" className="w-full bg-indigo-600 hover:bg-indigo-500 text-white">
                    Unlock my heart <Heart className="ml-2 w-4 h-4 fill-current" />
                  </Button>
                </form>
              </motion.div>
            </PageContent>
          </>
        )}
      </AnimatePresence>
    </BookLayout>
  );
}
