import { useStorySession } from "@/hooks/use-story";
import { useLocation } from "wouter";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { StarField } from "@/components/StarField";
import { RotateCcw } from "lucide-react";

export default function Finale() {
  const { data: session } = useStorySession();
  const [, setLocation] = useLocation();

  const handleRestart = () => {
    localStorage.removeItem("stargazer_session_id");
    window.location.href = "/";
  };

  return (
    <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center p-8 relative overflow-hidden">
      <StarField />
      
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 1 }}
        className="z-10 text-center max-w-2xl bg-slate-900/50 p-12 rounded-2xl border border-slate-800 backdrop-blur-md shadow-2xl"
      >
        <h1 className="text-5xl font-display text-transparent bg-clip-text bg-gradient-to-r from-indigo-200 via-white to-purple-200 mb-8">
          The End
        </h1>
        
        <p className="text-xl text-slate-300 font-serif leading-relaxed mb-8">
          Thank you for reading The Stargazer. Your journey has been recorded in the stars.
        </p>

        {session && (
          <div className="text-sm text-slate-500 font-mono mb-8 p-4 bg-slate-950 rounded border border-slate-800 inline-block">
            SESSION ID: {session.sessionId.slice(0, 8)}...
            <br/>
            PATH: {session.storyPath.toUpperCase()}
          </div>
        )}

        <div>
          <Button 
            onClick={handleRestart}
            variant="secondary"
            className="px-8 py-6 text-lg"
          >
            <RotateCcw className="mr-2 w-5 h-5" />
            Read Again
          </Button>
        </div>
      </motion.div>
    </div>
  );
}
