import { useCreateSession, useStorySession } from "@/hooks/use-story";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import { BookOpen, Sparkles, Star } from "lucide-react";
import { useEffect } from "react";
import { StarField } from "@/components/StarField";

export default function Home() {
  const { data: session } = useStorySession();
  const createSession = useCreateSession();
  const [, setLocation] = useLocation();

  useEffect(() => {
    // If a session already exists and has progress, we could auto-redirect, 
    // but a menu is nicer.
  }, [session]);

  const handleStart = async () => {
    if (session) {
      // Continue existing
      setLocation(`/chapter/${session.currentChapter}`);
    } else {
      // Create new
      const newSession = await createSession.mutateAsync();
      setLocation(`/chapter/${newSession.currentChapter}`);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 flex items-center justify-center p-4 relative overflow-hidden">
      <StarField />
      
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-slate-900/90 z-10 pointer-events-none" />

      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 1 }}
        className="relative z-20 max-w-2xl w-full text-center space-y-12"
      >
        <div className="space-y-6">
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ delay: 0.2, duration: 0.8 }}
            className="w-32 h-32 mx-auto bg-gradient-to-tr from-indigo-500 to-purple-600 rounded-full blur-2xl opacity-50 absolute top-0 left-1/2 -translate-x-1/2 -translate-y-12"
          />
          <h1 className="text-6xl md:text-8xl font-display text-transparent bg-clip-text bg-gradient-to-br from-indigo-100 via-purple-100 to-amber-100 drop-shadow-[0_0_15px_rgba(255,255,255,0.3)]">
            The Stargazer
          </h1>
          <p className="text-xl md:text-2xl text-indigo-200/80 font-serif italic max-w-md mx-auto">
            "We are all looking for something in the vastness of the dark."
          </p>
        </div>

        <div className="flex flex-col items-center gap-6">
          <Button 
            size="lg"
            onClick={handleStart}
            disabled={createSession.isPending}
            className="
              px-12 py-8 text-xl rounded-full font-serif tracking-wide
              bg-white/10 hover:bg-white/20 text-white border border-white/20
              backdrop-blur-sm transition-all duration-300
              shadow-[0_0_20px_rgba(255,255,255,0.1)] hover:shadow-[0_0_30px_rgba(255,255,255,0.2)]
              group
            "
          >
            {createSession.isPending ? "Preparing Stars..." : session ? "Continue Journey" : "Begin Story"}
            {!createSession.isPending && (
              <Sparkles className="ml-3 w-5 h-5 group-hover:rotate-12 transition-transform" />
            )}
          </Button>
          
          {session && (
             <Button
               variant="link"
               onClick={() => {
                 localStorage.removeItem("stargazer_session_id");
                 window.location.reload();
               }}
               className="text-slate-500 hover:text-slate-400 text-sm"
             >
               Reset Progress
             </Button>
          )}
        </div>
      </motion.div>

      {/* Decorative elements */}
      <motion.div 
        animate={{ rotate: 360 }}
        transition={{ duration: 100, repeat: Infinity, ease: "linear" }}
        className="absolute -bottom-1/2 -right-1/4 w-[1000px] h-[1000px] rounded-full border border-white/5 border-dashed"
      />
      <motion.div 
        animate={{ rotate: -360 }}
        transition={{ duration: 150, repeat: Infinity, ease: "linear" }}
        className="absolute -bottom-1/2 -left-1/4 w-[800px] h-[800px] rounded-full border border-white/5 border-dashed"
      />
    </div>
  );
}
