import { useStorySession, useUpdateStory } from "@/hooks/use-story";
import { StarField } from "@/components/StarField";
import { useLocation } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import { Loader2 } from "lucide-react";
import { useState } from "react";

const STORY_PAGES = [
  {
    content: "Long ago, in a bamboo grove shrouded in silver mist, an old cutter found a glowing stalk that pulsated with a rhythm not of this earth. Inside was a tiny girl, no larger than a thumb, shining with a pure, ethereal light that seemed to draw from the moon itself. He took her home, and from that day on, his life was blessed with a fortune he could never have imagined, though it was her presence alone that brought true wealth to his humble home.",
    word: "moon"
  },
  {
    content: "The girl grew with unnatural speed into a woman of radiant beauty, her skin as pale as the winter snow and her hair like silk woven from midnight. Princes and kings from across the land came to win her hand, offering impossible treasures—the legendary branch from Mount Horai, the skin of a fire-rat, the jewel from a dragon's neck, and chalices filled with the tears of angels. But she turned them all away, for their gold and gems could never replace the quiet light in her eyes that only the stars understood.",
    word: "beauty"
  },
  {
    content: "Yet beneath her graceful smile, Kaguya carried a secret heavier than any mortal burden. She was not of this world, and the celestial pull was becoming too strong to ignore. On nights of the full moon, she would gaze upward with tears streaming down her porcelain cheeks, knowing her heart belonged to the sky and the silence between the stars. The time had come for her to return, leaving behind the only truth she ever found in the fragile, warm world of mortals—a secret waiting to be spoken by a soul brave enough to look beyond the veil.",
    word: "sky"
  }
];

export default function Chapter3() {
  const { data: session, isLoading } = useStorySession();
  const updateStory = useUpdateStory();
  const [, setLocation] = useLocation();
  const [currentPage, setCurrentPage] = useState(0);

  if (isLoading || !session) return <div className="min-h-screen bg-slate-950 flex items-center justify-center"><Loader2 className="animate-spin text-white" /></div>;

  const handleNext = async () => {
    if (currentPage < STORY_PAGES.length - 1) {
      setCurrentPage(currentPage + 1);
    } else {
      await updateStory.mutateAsync({ currentChapter: 4 });
      setLocation("/chapter/4");
    }
  };

  const renderText = (text: string, targetWord: string) => {
    const parts = text.split(new RegExp(`(${targetWord})`, 'gi'));
    return parts.map((part, i) => {
      if (part.toLowerCase() === targetWord.toLowerCase()) {
        return (
          <span
            key={i}
            onClick={handleNext}
            className="text-indigo-400 font-bold underline decoration-indigo-500/50 hover:text-indigo-300 cursor-pointer transition-all duration-300 hover:drop-shadow-[0_0_10px_rgba(129,140,248,0.8)]"
          >
            {part}
          </span>
        );
      }
      return part;
    });
  };

  return (
    <div className="min-h-screen bg-slate-950 flex items-center justify-center p-4 md:p-8 relative overflow-hidden">
      <StarField />
      
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-slate-900/90 z-10 pointer-events-none" />

      <div className="relative z-20 w-full max-w-5xl">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentPage}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.6 }}
            className="bg-slate-900/60 backdrop-blur-xl rounded-3xl border border-indigo-500/20 p-8 md:p-16 shadow-2xl"
          >
            {/* Chapter indicator */}
            <div className="flex justify-center mb-8">
              <motion.div
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                className="w-24 h-24 rounded-full border-2 border-indigo-500/40 flex items-center justify-center bg-indigo-950/30"
              >
                <span className="text-4xl text-indigo-200 font-display">{currentPage + 1}</span>
              </motion.div>
            </div>

            {/* Title */}
            <h2 className="text-4xl md:text-5xl font-display text-center text-transparent bg-clip-text bg-gradient-to-br from-indigo-100 via-purple-100 to-amber-100 mb-12 drop-shadow-[0_0_15px_rgba(255,255,255,0.3)]">
              Kaguya's Tale
            </h2>

            {/* Divider */}
            <div className="w-full h-px bg-gradient-to-r from-transparent via-indigo-500/50 to-transparent mb-12"></div>

            {/* Story content */}
            <div className="prose prose-invert prose-xl md:prose-2xl max-w-none text-center">
              <p className="text-indigo-50 font-serif leading-relaxed text-lg md:text-2xl">
                {renderText(STORY_PAGES[currentPage].content, STORY_PAGES[currentPage].word)}
              </p>
            </div>

            {/* Instruction */}
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 1 }}
              className="mt-16 text-center"
            >
              <p className="text-indigo-400/60 text-sm md:text-base italic font-serif tracking-wide">
                Click the key word to continue the story...
              </p>
            </motion.div>

            {/* Page indicators */}
            <div className="flex justify-center gap-2 mt-8">
              {STORY_PAGES.map((_, index) => (
                <div 
                  key={index}
                  className={`w-2 h-2 rounded-full transition-all duration-300 ${
                    index === currentPage 
                      ? 'bg-indigo-400 w-8' 
                      : index < currentPage 
                        ? 'bg-indigo-600/50' 
                        : 'bg-slate-700'
                  }`}
                />
              ))}
            </div>
          </motion.div>
        </AnimatePresence>
      </div>
    </div>
  );
}
