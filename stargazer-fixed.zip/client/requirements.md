## Packages
framer-motion | Complex animations for page transitions and visual effects
lucide-react | Iconography
wouter | Routing
zod | Schema validation
@hookform/resolvers | Form validation with Zod
react-hook-form | Form state management

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  sans: ["'DM Sans'", "sans-serif"],
  serif: ["'Libre Baskerville'", "serif"],
  display: ["'Playfair Display'", "serif"],
  mono: ["'JetBrains Mono'", "monospace"],
}
