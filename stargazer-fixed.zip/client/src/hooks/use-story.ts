import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import { type InsertStoryProgress, type UpdateStoryProgress } from "@shared/schema";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";

const SESSION_KEY = "stargazer_session_id";

// Helper to get or create session ID
export function useSessionId() {
  const [sessionId] = useState(() => {
    const stored = localStorage.getItem(SESSION_KEY);
    if (stored) return stored;
    // We will let the backend handle creation if we don't have one, 
    // or we can generate a UUID here. For simplicity, we'll null check in components 
    // and create a new session if needed.
    return null;
  });
  
  const setSessionId = (id: string) => {
    localStorage.setItem(SESSION_KEY, id);
    // Force reload/re-render might be needed if not using context, 
    // but React Query invalidation usually handles data updates.
  };

  return { sessionId, setSessionId };
}

export function useStorySession() {
  const { sessionId } = useSessionId();
  
  return useQuery({
    queryKey: [api.story.get.path, sessionId],
    queryFn: async () => {
      if (!sessionId) return null;
      const url = buildUrl(api.story.get.path, { sessionId });
      const res = await fetch(url);
      if (res.status === 404) return null;
      if (!res.ok) throw new Error("Failed to load story session");
      return api.story.get.responses[200].parse(await res.json());
    },
    enabled: !!sessionId
  });
}

export function useCreateSession() {
  const queryClient = useQueryClient();
  const { setSessionId } = useSessionId();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async () => {
      // Create a random session ID for the frontend to track
      const newSessionId = crypto.randomUUID();
      const input: InsertStoryProgress = {
        sessionId: newSessionId,
        currentChapter: 1,
        storyPath: "standard"
      };
      
      const res = await fetch(api.story.create.path, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(input),
      });

      if (!res.ok) throw new Error("Failed to start new story");
      const data = api.story.create.responses[201].parse(await res.json());
      return data;
    },
    onSuccess: (data) => {
      setSessionId(data.sessionId);
      queryClient.setQueryData([api.story.get.path, data.sessionId], data);
      toast({
        title: "Journey Started",
        description: "Your story progress has been saved locally.",
      });
      // Force a window reload to pick up the new session ID in hooks if necessary
      // or rely on the query client update.
      // A cleaner way is using a Context, but for now this works.
      if (!localStorage.getItem(SESSION_KEY)) {
         localStorage.setItem(SESSION_KEY, data.sessionId);
         window.location.reload(); 
      }
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Could not start the story. Please try again.",
        variant: "destructive"
      });
    }
  });
}

export function useUpdateStory() {
  const queryClient = useQueryClient();
  const { sessionId } = useSessionId();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (updates: UpdateStoryProgress) => {
      if (!sessionId) throw new Error("No active session");
      
      const url = buildUrl(api.story.update.path, { sessionId });
      const res = await fetch(url, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(updates),
      });

      if (!res.ok) throw new Error("Failed to update story");
      return api.story.update.responses[200].parse(await res.json());
    },
    onSuccess: (data) => {
      queryClient.setQueryData([api.story.get.path, sessionId], data);
    },
    onError: () => {
      toast({
        title: "Connection Lost",
        description: "Failed to save your progress.",
        variant: "destructive"
      });
    }
  });
}
